# Onsaldo — Workspace redesign

A responsive, static HTML prototype with a redesigned information architecture:
- Workspace overview
- Task board (Kanban)
- Document hub
- Finance
- VAT center
- Obligations calendar
- Reports
- AI assistant demo

Open `onsaldo-workspace.html` in a browser. No build step or dependencies required.
All financial data and interactions are demo-only; no backend/API is connected.
